<div id="layerslider_6" class="ls-wp-container" style="width: 100%; height: 460px; margin: 0px auto; ">
    <div class="ls-layer"
        style="slidedirection: right; slidedelay: 4000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/09/backgrounda1.jpg')  }}"
            style="position: absolute; top: -23px; left: -1031px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 0; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/09/woman4.png' )  }}"
            style="position: absolute; top: 100px; left: 519px; slidedirection : right; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/drive-your-business-to-profitability3.png"  )  }}"
            style="position: absolute; top: 230px; left: 33px; slidedirection : fade; slideoutdirection : fade;  durationin : 2200; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1200; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1"
            src="{{  asset("asset/content/images/all/09/Let-help.png" )  }}"
            style="position: absolute; top: 195px; left: 30px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 900; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/Take-your-business-to-the-next-level.png" )  }}"
            style="position: absolute; top: 113px; left: 23px; slidedirection : top; slideoutdirection : top;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 700; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/08/get-started.png")  }}"
            style="position: absolute; top: 280px; left: 35px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500; delayout : 0; showuntil : 0; ">
    </div>

    <div class="ls-layer"
        style="slidedirection: right; slidedelay: 4000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/10/Untitled-1.jpg" )  }}"
            style="position: absolute; top: -17px; left: -570px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 0; delayout : 0; showuntil : 0; ">

       <!-- <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/08/Theme-.png" )  }}"
            style="position: absolute; top: 294px; left: 1px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 1200; delayout : 0; showuntil : 0; ">-->
        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/top-notch-ICT-services.png")  }}"
            style="position: absolute; top: 173px; left: 0px; slidedirection : left; slideoutdirection : left;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 800; delayout : 0; showuntil : 0; ">
            
                
        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/over-10-years.png"  )  }}"
            style="position: absolute; top: 84px; left: -5px; slidedirection : left; slideoutdirection : left;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">

            <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/clientlogos_small.png') }}"
            style="position: absolute; top: -36px; left: 361px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 1100; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/clientlogos_BIG.png') }}"
            style="position: absolute; top: 161px; left: 350px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 800; delayout : 0; showuntil : 0; ">
         <!--   
        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/08/iMac-staunch-xcel.png' )  }}"
            style="position: absolute; top: 64px; left: 502px; slidedirection : right; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/08/ipad-staunch-xcel.png')  }}"
            style="position: absolute; top: 147px; left: 758px; slidedirection : top; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 800; delayout : 0; showuntil : 0; ">
         -->

        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/09/diverse-section-of-economy.png')  }}"
            style="position: absolute; top: 200px; left: 0px;    durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 0; delayout : 0; showuntil : 0; ">

            <a href={{ asset('staunch_ems') }}>
                <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/08/view-clientele.png")  }}"
                    style="position: absolute; top: 240px; left: 8px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500; delayout : 0; showuntil : 0; "></a> 
                
    </div>
<!--
    <div class="ls-layer"
        style="slidedirection: right; slidedelay: 4000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

        <img alt="img" class="ls-s-1"
            src="{{  asset( 'asset/content/images/all/08/034ac8b0-2bb2-4fd2-8754-ab3fd2315d54_hero-background.png') }}"
            style="position: absolute; top: 0px; left: -532px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 0; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/08/irectly-from-other-dev-.png' )  }}"
            style="position: absolute; top: 206px; left: 499px; slidedirection : top; slideoutdirection : top;  durationin : 2000; durationout : 2000; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 800; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/08/Layer-2-.png' )  }}"
            style="position: absolute; top: 305px; left: 641px; slidedirection : bottom; slideoutdirection : left;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1400; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1"
            src="{{  asset('asset/content/images/all/08/MAXiMUS-Responsive-Multi-Purpose-Theme.png' )  }}"
            style="position: absolute; top: 75px; left: 497px; slidedirection : top; slideoutdirection : top;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1200; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/08/maximus-slider-3.png') }}"
            style="position: absolute; top: 328px; left: 499px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1900; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/iphone-mockup-white1222.png') }}"
            style="position: absolute; top: 23px; left: 26px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">
    </div>
-->



    <div class="ls-layer"
        style="slidedirection: right; slidedelay: 4000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

        <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/bg-11.png') }}"
            style="position: absolute; top: -318px; left: -538px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 200; delayout : 0; showuntil : 0; ">


<img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/08/iMac-staunch-xcel.png' )  }}"
            style="position: absolute; top: 64px; left: 502px; slidedirection : right; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/08/ipad-staunch-xcel.png')  }}"
            style="position: absolute; top: 147px; left: 758px; slidedirection : top; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 800; delayout : 0; showuntil : 0; ">

            <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/and-run-your-school-with-ease.png"  )  }}"
            style="position: absolute; top: 220px; left: 33px; slidedirection : fade; slideoutdirection : fade;  durationin : 2200; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1200; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1"
            src="{{  asset("asset/content/images/all/09/Subscribe-to-Staunch-Xcel.png" )  }}"
            style="position: absolute; top: 195px; left: 30px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 900; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/School-management-should-not.png" )  }}"
            style="position: absolute; top: 113px; left: 23px; slidedirection : top; slideoutdirection : top;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 700; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/08/get-started.png")  }}"
            style="position: absolute; top: 250px; left: 35px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500; delayout : 0; showuntil : 0; ">


    </div>













    <div class="ls-layer"
    style="slidedirection: right; slidedelay: 7000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

    <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/bg-11.png') }}"
        style="position: absolute; top: -318px; left: -538px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 200; delayout : 0; showuntil : 0; ">


        

    <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/everything-about-your-Estate.png"  )  }}"
        style="position: absolute; top: 20px; left: 8px; slidedirection : left; slideoutdirection : left;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">

<img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/09/StaunchEM-is-specially.png')  }}"
        style="position: absolute; top: 100px; left: 14px;    durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin
        : 0; delayout : 0; showuntil : 0; ">



<!--
    <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/theme-options-smaller-ok.png') }}"
        style="position: absolute; top: -36px; left: 307px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 1100; delayout : 0; showuntil : 0; ">

    <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/page-builder-smaller.png') }}"
        style="position: absolute; top: 161px; left: 296px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 800; delayout : 0; showuntil : 0; ">


<img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/08/iMac-staunch-xcel.png' )  }}"
        style="position: absolute; top: 64px; left: 502px; slidedirection : right; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">
        -->

    <img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/09/phone.png')  }}"
        style="position: absolute; top: 50px; left: 500px; slidedirection : top; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutElastic; easingout : easeInOutQuint; delayin : 800; delayout : 0; showuntil : 0; ">

    <h4 class="ls-s-1 slider_bg_cl"
        style="position: absolute; top:141px; left: 15px; slidedirection : fade; slideoutdirection : fade; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1400; delayout : 0; showuntil : 0; padding:7px 10px; font-size:16px; color: #fff;  white-space: nowrap;">
        Estate Security & Emergency management </h4>

    <h4 class="ls-s-1 slider_bg_cl"
        style="position: absolute; top:185px; left: 15px; slidedirection : fade; slideoutdirection : fade; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1800; delayout : 0; showuntil : 0; padding:7px 10px; font-size:16px; color: #fff;  white-space: nowrap;">
        Resident management </h4>

    <h4 class="ls-s-1 slider_bg_cl"
        style="position: absolute; top:228px; left: 15px; slidedirection : fade; slideoutdirection : fade; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 2600; delayout : 0; showuntil : 0; padding:7px 10px; font-size:16px; color: #fff;  white-space: nowrap;">
        Estate Dues & payment management </h4>

    <h4 class="ls-s-1 slider_bg_cl"
        style="position: absolute; top:270px; left: 15px; slidedirection : fade; slideoutdirection : fade; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 3000; delayout : 0; showuntil : 0; padding:7px 10px; font-size:16px; color: #fff;  white-space: nowrap;">
         Visitor management</h4>

    <h4 class="ls-s-1 slider_bg_cl"
        style="position: absolute; top:312px; left: 15px; slidedirection : fade; slideoutdirection : fade; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 3600; delayout : 0; showuntil : 0; padding:7px 10px; font-size:16px; color: #fff;  white-space: nowrap;">
        Businesses registrations and management </h4>

        <h4 class="ls-s-1 slider_bg_cl"
        style="position: absolute; top:355px; left: 15px; slidedirection : fade; slideoutdirection : fade; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 4200; delayout : 0; showuntil : 0; padding:7px 10px; font-size:16px; color: #fff;  white-space: nowrap;">
        Estate managers & Residents communication </h4>

        <h4 class="ls-s-1 slider_bg_cl"
        style="position: absolute; top:398px; left: 15px; slidedirection : fade; slideoutdirection : fade; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 4800; delayout : 0; showuntil : 0; padding:7px 10px; font-size:16px; color: #fff;  white-space: nowrap;">
        House aids registration and management </h4>
</div>





<div class="ls-layer"
style="slidedirection: right; slidedelay: 4000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

<img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/bg-11.png') }}"
    style="position: absolute; top: -318px; left: -538px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 200; delayout : 0; showuntil : 0; ">


<img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/09/pos-notepad3.png' )  }}"
    style="position: absolute; top: 10px; left: 502px; slidedirection : right; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">
 
    <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/simultaneously-anywhere-anytime.png"  )  }}"
    style="position: absolute; top: 200px; left: 33px; slidedirection : fade; slideoutdirection : fade;  durationin : 2200; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1200; delayout : 0; showuntil : 0; ">

<img alt="img" class="ls-s-1"
    src="{{  asset("asset/content/images/all/09/Track-both-your-sales-and-inventory.png" )  }}"
    style="position: absolute; top: 160px; left: 30px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 900; delayout : 0; showuntil : 0; ">

<img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/Automate-your-store.png" )  }}"
    style="position: absolute; top: 113px; left: 23px; slidedirection : top; slideoutdirection : top;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 700; delayout : 0; showuntil : 0; ">
<a href={{ asset('staunch_ems') }}>
<img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/08/get-started.png")  }}"
    style="position: absolute; top: 240px; left: 35px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500; delayout : 0; showuntil : 0; "></a>


</div>


<div class="ls-layer"
style="slidedirection: right; slidedelay: 4000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

<img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/bg-11.png') }}"
    style="position: absolute; top: -318px; left: -538px; slidedirection : fade; slideoutdirection : fade;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 200; delayout : 0; showuntil : 0; ">


<img alt="img" class="ls-s-1" src="{{  asset('asset/content/images/all/09/servers2.png' )  }}"
    style="position: absolute; top: 10px; left: 550px; slidedirection : right; slideoutdirection : right;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 500; delayout : 0; showuntil : 0; ">
 
    <img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/the-digital-world-will-offer-you.png"  )  }}"
    style="position: absolute; top: 220px; left: 33px; slidedirection : fade; slideoutdirection : fade;  durationin : 2200; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1200; delayout : 0; showuntil : 0; ">

<img alt="img" class="ls-s-1"
    src="{{  asset("asset/content/images/all/09/Dont-lose-out-on-the-business-potential.png") }}"
    style="position: absolute; top: 190px; left: 30px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 900; delayout : 0; showuntil : 0; ">

<img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/09/Register-and-host-your-domain-name.png" )  }}"
    style="position: absolute; top: 113px; left: 23px; slidedirection : top; slideoutdirection : top;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 700; delayout : 0; showuntil : 0; ">
<a href={{ route('projects.show', 2) }}>
<img alt="img" class="ls-s-1" src="{{  asset("asset/content/images/all/08/get-started.png")  }}"
    style="position: absolute; top: 250px; left: 35px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500; delayout : 0; showuntil : 0; "></a>


</div>













<!--

    <div class="ls-layer"
        style="slidedirection: right; slidedelay: 4000; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0; ">

        <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/bg-11.png') }}"
            style="position: absolute; top: -61px; left: -492px; slidedirection : fade; slideoutdirection : fade;  durationin : 1800; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 200; delayout : 0; showuntil : 0; ">

        <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/09/11.png') }}"
            style="position: absolute; top: 30px; left: 424px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 400; delayout : 0; showuntil : 0; ">

        <h1 class="ls-s-1"
            style="position: absolute; top:168px; left: 291px; slidedirection : left; slideoutdirection : left; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 700; delayout : 0; showuntil : 0; font-weight:200;  font-family: Open Sans; color: #fff;  white-space: nowrap;">
            POWERFULLY </h1>

        <h1 class="ls-s-1"
            style="position: absolute; top:219px; left: 27px; slidedirection : left; slideoutdirection : left; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1000; delayout : 0; showuntil : 0; font-weight:700; padding:10px 15px;border-bottom:1px solid #fff; border-top:1px solid #fff; font-family: Open Sans; font-size: 38px; line-height: 38px; color: #fff;  white-space: nowrap;">
            RESPONSIVE & RETINA </h1>

        <img alt="img" class="ls-s-1" src="{{ asset('asset/content/images/all/08/Theme-.png') }}"
            style="position: absolute; top: 305px; left: 262px; slidedirection : bottom; slideoutdirection : bottom;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1300; delayout : 0; showuntil : 0; ">
    </div>
-->

</div>